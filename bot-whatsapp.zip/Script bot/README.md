• bot-wa by Shuichi

 Cara install bot:

$ pkg install git

$ pkg update && pkg upgrade

$ git clone https://github.com/Shuichi126/bot-whatsapp

$ cd bot-wa

$ pkg install wget

$ pkg install ffmpeg

$ pkg install nodejs

$ npm i -g cwebp

$ npm i -g ytdl

$ npm i

$ npm i got

$ node index.js

